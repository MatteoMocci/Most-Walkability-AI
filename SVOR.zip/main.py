import pandas as pd
import numpy as np
from sklearn.svm import LinearSVC, SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.base import clone
from sklearn.svm import SVR

# Funzione per la creazione e il salvataggio di un dataset di classificazione ordinale non lineare
def create_and_save_nonlinear_ordinal_dataset(n_samples=1000, n_features=10, noise=0.1, q2=0.0, q3=0.0):
    np.random.seed(42)
    linear_coefficients = np.random.rand(n_features)
    quadratic_coefficients = np.random.rand(n_features)
    cubic_coefficients = np.random.rand(n_features)
    # Genera features random
    X = np.random.randn(n_samples, n_features)
    # Calcola la risposta non lineare
    y_nonlinear = np.dot(X, linear_coefficients) +q2*np.dot(X ** 2, quadratic_coefficients) \
                  + q3*np.dot(X ** 3, cubic_coefficients) + np.random.normal(0, noise, n_samples)
    y_normalized = (y_nonlinear - y_nonlinear.min()) / (y_nonlinear.max() - y_nonlinear.min())
    # Divide in classi ordinate (ad es., 1 a 5)
    y_sorted_indices = np.argsort(y_normalized)
    y_classes = np.empty(n_samples, dtype=int)
    # Divide gli indici equamente tra le 5 classi
    n_classes = 5
    labels_per_class = n_samples // n_classes
    for i in range(n_classes):
        start_index = i * labels_per_class
        end_index = start_index + labels_per_class
        if i == n_classes - 1:
            end_index = n_samples
        y_classes[y_sorted_indices[start_index:end_index]] = i + 1  # Etichette da 1 a 5
    # Crea un DataFrame per le feature e aggiunge la colonna label
    data = pd.DataFrame(X, columns=[f'feature_{i + 1}' for i in range(n_features)])
    data['target'] = y_classes
    # Divisione in train e test set con stratificazione
    X_train, X_test, y_train, y_test = train_test_split(data.drop('target', axis=1), data['target'], test_size=0.2,
                                                        random_state=42, stratify=data['target'])
    X_train.to_csv('X_train_large.csv', index=False)
    X_test.to_csv('X_test_large.csv', index=False)
    y_train.to_csv('y_train_large.csv', index=False)
    y_test.to_csv('y_test_large.csv', index=False)
    print("Files saved: X_train_nonlinear_large.csv, X_test_nonlinear_large.csv, y_train_nonlinear_large.csv, y_test_nonlinear_large.csv")


# Classe SVOR per la classificazione ordinale
# La classe SVOR adotta un approccio in cui il margine
# tra classi consecutive viene massimizzato. Questo metodo si ispira direttamente
# alla strategia di SVM per due classi, estendendola per operare efficacemente
# in scenari con molteplici classi ordinate.

# 1) Definizione dei Margini: I margini vengono definiti come la media dei valori
#    di soglia tra le classi uniche adiacenti. Ciò si traduce nel calcolo di soglie
#    che dividono i dati in k classi ordinate, con l'obiettivo di massimizzare il margine
#    tra ciascuna coppia di classi consecutive.

# 2) Addestramento dei Modelli Binari: Per ogni soglia, viene addestrato un modello SVM binario.
#    Ogni modello è responsabile per distinguere tra le classi da una parte e tutte le classi
#    superiori dall'altra, offrendo un approccio granulare alla classificazione ordinale.

# 3) Predizione Aggregata: Durante la fase di predizione, le decisioni di tutti i modelli binari
#    vengono aggregate. La predizione finale per ogni esempio nel set di test è data dalla somma
#    dei risultati delle funzioni di decisione di tutti i modelli, dove il conteggio dei 'superamenti'
#    determina la classe finale. Questo approccio sfrutta la posizione relativa di un esempio rispetto
#    a tutti gli iperpiani di decisione per determinare la sua classificazione.
class SVOR:
    def __init__(self, model):
        self.model = model
        self.models = []
        self.thresholds = []

    def fit(self, X, y):
        unique_classes = np.unique(y)
        self.thresholds = [(unique_classes[i] + unique_classes[i + 1]) / 2 for i in range(len(unique_classes) - 1)]
        for threshold in self.thresholds:
            binary_y = (y > threshold).astype(int)
            model_clone = clone(self.model)
            model_clone.fit(X, binary_y)
            self.models.append(model_clone)

    def predict(self, X):
        predictions = np.zeros((X.shape[0], len(self.models)))
        for i, model in enumerate(self.models):
            predictions[:, i] = model.decision_function(X)
        return np.sum(predictions > 0, axis=1) + 1



# Classe SVOR2 per la classificazione ordinale che considera tutte le possibili coppie di classi,
# non limitandosi solo a quelle adiacenti.
#
# 1) Definizione di Coppie di Classi: genera tutte le possibili coppie di classi uniche nel dataset.
#    Questo passaggio non si limita a classi consecutive ma include ogni combinazione possibile,
#    aumentando la capacità del modello di apprendere distinzioni più fini tra le classi.
#
# 2) Addestramento dei Modelli Binari per Ogni Coppia: per ciascuna coppia di classi, viene addestrato
#    un modello binario specifico. Questo approccio è simile al training SVM tradizionale, ma applicato
#    a un contesto multiclasse molto più ampio. Ogni modello binario viene addestrato per distinguere
#    tra due classi specifiche, rendendo il modello complessivo capace di gestire relazioni complesse
#    tra molteplici classi.
#
# 3) Predizione Aggregata: durante la fase di predizione, la classe finale per un dato esempio viene
#    determinata sommando i punteggi (o voti) ottenuti da ogni modello binario. Il modello aggrega
#    le decisioni da tutti i modelli binari, e la classe che ottiene il punteggio più alto viene scelta
#    come previsione finale. Questo metodo aggregato consente di sfruttare l'informazione raccolta
#    da molteplici modelli binari per fare una scelta informata sulla classificazione finale.
#
class SVOR2:
    def __init__(self, model):
        self.model = model
        self.models = []
        self.class_pairs = []
        self.unique_classes = None

    def fit(self, X, y):
        # Memorizza le classi uniche dal set di training
        self.unique_classes = np.unique(y)
        # Genera tutte le possibili coppie di classi
        for i in range(len(self.unique_classes) - 1):
            for j in range(i + 1, len(self.unique_classes)):
                self._fit_pair(X, y, self.unique_classes[i], self.unique_classes[j])

    def _fit_pair(self, X, y, class1, class2):
        # Seleziona solo i dati che appartengono a class1 o class2
        mask = (y == class1) | (y == class2)
        binary_X = X[mask]
        binary_y = y[mask]

        # Mappa le etichette di y a 0 e 1 per il training binario
        binary_y = np.where(binary_y == class1, 0, 1)  # 0 per class1, 1 per class2

        # Controlla se ci sono esempi di entrambe le classi
        if np.unique(binary_y).size < 2:
            print(f"Skipping training for classes {class1} and {class2}: not enough class samples.")
            return

        model_clone = clone(self.model)
        model_clone.fit(binary_X, binary_y)
        self.models.append(model_clone)
        self.class_pairs.append((class1, class2))

    def predict(self, X):
        # array di zeri con una colonna per ogni classe unica
        scores = np.zeros((X.shape[0], len(self.unique_classes)))
        # Aggiunge voti ai punteggi basati sulle decisioni dei modelli
        for model, (class1, class2) in zip(self.models, self.class_pairs):
            decisions = model.predict(X)
            # Aggiorna scores usando gli indici corretti per class1 e class2
            index1 = np.where(self.unique_classes == class1)[0][0]
            index2 = np.where(self.unique_classes == class2)[0][0]
            scores[:, index1] += decisions == 0
            scores[:, index2] += decisions == 1
        # Ritorna la classe con il punteggio più alto per ogni esempio
        return self.unique_classes[np.argmax(scores, axis=1)]


# Classe OrdinalSVC per la classificazione ordinale
# Approccio dei modelli cumulativi per la classificazione ordinale
# adattando il metodo SVM per gestire dati ordinati attraverso una serie di modelli binari.

# Margine Cumulativo: anziché confrontare coppie di classi adiacenti o non,
# questa classe confronta ciascuna classe con tutte le classi successive.
# Questo approccio è simile al modello cumulativo utilizzato nella regressione logistica ordinale,
# dove ogni classe viene confrontata con l'aggregato delle classi che la superano, formando
# un modello 'link' cumulativo.

# 1) Definizione dei Margini: i margini non sono calcolati tra classi adiacenti, ma piuttosto
# ogni classe viene considerata contro la combinazione di tutte le classi successive.
# Questo metodo produce modelli che apprendono a distinguere una classe da tutte quelle che
# sono considerate 'maggiori' secondo l'ordine ordinale.

# 2) Addestramento dei Modelli Binari: Un modello SVM viene addestrato per ogni classe,
# dove il target binario è definito come 0 per la classe corrente e 1 per tutte le classi
# che hanno un'etichetta maggiore. Questo crea una serie di modelli binari che, collettivamente,
# apprendono la struttura ordinale dell'intero set di classi.

# 3) Predizione Aggregata: Durante la predizione, la funzione di decisione di ogni modello SVM
# è utilizzata per calcolare un punteggio per ogni soglia di classe. Questi punteggi sono poi
# sommati sequenzialmente per determinare la classe finale di ogni esempio. Questo metodo di aggregazione
# assume che i confini di decisione tra le classi siano sequenziali e che un conteggio cumulativo dei
# punteggi positivi indichi la classe più appropriata.
class OrdinalSVC:
    def __init__(self, C=1.0, kernel='linear'):
        self.C = C
        self.kernel = kernel
        self.models = []

    def fit(self, X, y):
        unique_classes = np.unique(y)
        for i in range(len(unique_classes) - 1):
            binary_y = (y > unique_classes[i]).astype(int)
            model = SVC(C=self.C, kernel=self.kernel)
            model.fit(X, binary_y)
            self.models.append(model)

    def predict(self, X):
        scores = np.zeros((X.shape[0], len(self.models)))
        for i, model in enumerate(self.models):
            scores[:, i] = model.decision_function(X)
        return np.sum(scores > 0, axis=1) + 1

#Normale regressione con risultati convertiti in classi ordinali
class OrdinalSVR:
    def __init__(self, C=1.0, epsilon=0.1, kernel='linear'):
        self.C = C
        self.epsilon = epsilon
        self.kernel = kernel
        self.model = SVR(C=self.C, epsilon=self.epsilon, kernel=self.kernel)
        self.thresholds = []

    # Questa funzione addestra un modello di regressione SVR sui dati di addestramento
    def fit(self, X, y):
        self.model.fit(X, y)
        unique_classes = np.unique(y)
        self.thresholds = [(unique_classes[i] + unique_classes[i + 1]) / 2 for i in range(len(unique_classes) - 1)]

    # Questa funzione predice le classi ordinali per i dati di test mappando i valori continui predetti sulle classi
    def predict(self, X):
        continuous_predictions = self.model.predict(X)
        ordinal_predictions = np.digitize(continuous_predictions, bins=self.thresholds)
        return ordinal_predictions + 1


# Funzione per confrontare i modelli di classificazione
def compare_models(X_train, X_test, y_train, y_test):
    #########################################################################################
    # Regressione
    ordinal_svr = OrdinalSVR()
    ordinal_svr.fit(X_train, y_train)
    y_pred = ordinal_svr.predict(X_test)
    print("\nSVR:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred)}')
    print(f'Precision: {precision_score(y_test, y_pred, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred, average="weighted")}')
    # print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred)}')


    #########################################################################################
    # Linear SVC
    linear_svc_model = SVOR(LinearSVC(C=1.0, max_iter=10000))
    linear_svc_model.fit(X_train, y_train)
    y_pred_linear = linear_svc_model.predict(X_test)

    print("\nLinear SVOR:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_linear)}')
    print(f'Precision: {precision_score(y_test, y_pred_linear, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_linear, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_linear, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_linear)}')

    #########################################################################################
    # Linear SVC
    linear_svc_model = SVOR2(LinearSVC(C=1.0, max_iter=10000))
    linear_svc_model.fit(X_train, y_train)
    y_pred_linear = linear_svc_model.predict(X_test)

    print("\nLinear SVOR2:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_linear)}')
    print(f'Precision: {precision_score(y_test, y_pred_linear, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_linear, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_linear, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_linear)}')

    #########################################################################################
    # SVC with RBF kernel
    rbf_svc_model = SVOR(SVC(C=1.0, gamma='auto', kernel='rbf'))
    rbf_svc_model.fit(X_train, y_train)
    y_pred_rbf = rbf_svc_model.predict(X_test)

    print("\nSVOR with RBF kernel:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_rbf)}')
    print(f'Precision: {precision_score(y_test, y_pred_rbf, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_rbf, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_rbf, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_rbf)}')


    #########################################################################################
    # SVC with RBF kernel
    rbf_svc_model = SVOR2(SVC(C=1.0, gamma='auto', kernel='rbf'))
    rbf_svc_model.fit(X_train, y_train)
    y_pred_rbf = rbf_svc_model.predict(X_test)

    print("\nSVOR2 with RBF kernel:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_rbf)}')
    print(f'Precision: {precision_score(y_test, y_pred_rbf, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_rbf, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_rbf, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_rbf)}')

    #########################################################################################
    # Ordinal SVC
    ordinal_svc_model = OrdinalSVC(C=1.0, kernel='linear')
    ordinal_svc_model.fit(X_train, y_train)
    y_pred_ordinal = ordinal_svc_model.predict(X_test)

    print("\nOrdinal SVC lineare:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_ordinal)}')
    print(f'Precision: {precision_score(y_test, y_pred_ordinal, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_ordinal, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_ordinal, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_ordinal)}')

    #########################################################################################
    # Ordinal SVC RBF
    ordinal_svc_model = OrdinalSVC(C=1.0, kernel='rbf')
    ordinal_svc_model.fit(X_train, y_train)
    y_pred_ordinal = ordinal_svc_model.predict(X_test)

    print("\nOrdinal SVC con RBF kernel:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_ordinal)}')
    print(f'Precision: {precision_score(y_test, y_pred_ordinal, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_ordinal, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_ordinal, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_ordinal)}')

    #########################################################################################
    # SVC senza considerare l'ordinalità
    rf_model = SVC(gamma='auto', kernel='linear')
    rf_model.fit(X_train, y_train)
    y_pred_rf = rf_model.predict(X_test)

    print("\nSVC lineare senza ordinalità:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_rf)}')
    print(f'Precision: {precision_score(y_test, y_pred_rf, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_rf, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_rf, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_rf)}')


    #########################################################################################
    # SVC senza considerare l'ordinalità
    rf_model = SVC(gamma='auto', kernel='rbf')
    rf_model.fit(X_train, y_train)
    y_pred_rf = rf_model.predict(X_test)

    print("\nSVC RBF senza ordinalità:")
    print(f'Accuracy: {accuracy_score(y_test, y_pred_rf)}')
    print(f'Precision: {precision_score(y_test, y_pred_rf, average="weighted")}')
    print(f'Recall: {recall_score(y_test, y_pred_rf, average="weighted")}')
    print(f'F1 Score: {f1_score(y_test, y_pred_rf, average="weighted")}')
    #print(f'Confusion Matrix:\n{confusion_matrix(y_test, y_pred_rf)}')


def main():
    create_and_save_nonlinear_ordinal_dataset(n_samples=2000, n_features=100, noise=0.0, q2=0.1, q3 = 0.0)
    #exit()

    X_train = pd.read_csv('X_train_large.csv')
    X_test = pd.read_csv('X_test_large.csv')
    y_train = pd.read_csv('y_train_large.csv').values.ravel()
    y_test = pd.read_csv('y_test_large.csv').values.ravel()
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    compare_models(X_train, X_test, y_train, y_test)


main()
